package com.klef.jfsd.exam;

import java.util.*;
import java.util.stream.Collectors;

class Project {
    private String projectName;
    private int duration;
    private double budget;
    private String teamLead;

    public Project(String projectName, int duration, double budget, String teamLead) {
        this.projectName = projectName;
        this.duration = duration;
        this.budget = budget;
        this.teamLead = teamLead;
    }

    public String getProjectName() {
        return projectName;
    }

    public double getBudget() {
        return budget;
    }

    @Override
    public String toString() {
        return "Project{" +
                "projectName='" + projectName + '\'' +
                ", duration=" + duration +
                ", budget=" + budget +
                ", teamLead='" + teamLead + '\'' +
                '}';
    }
}