package com.klef.jfsd.exam;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.criteria.*;

public class ClientDemo {
    public static void main(String[] args) {
        // Creating a list of projects
        List<Project> projects = new ArrayList<>();
        projects.add(new Project("AI Research", 12, 50000.0, "John Doe"));
        projects.add(new Project("E-Commerce Platform", 8, 75000.0, "Alice Smith"));
        projects.add(new Project("Healthcare System", 10, 90000.0, "Bob Johnson"));
        projects.add(new Project("FinTech App", 6, 120000.0, "Mary Brown"));
        projects.add(new Project("Education Portal", 15, 60000.0, "Chris Evans"));

        // Perform aggregate operations
        performAggregateFunctions(projects);
    }

    private static void performAggregateFunctions(List<Project> projects) {
        // Count of projects
        long count = projects.size();
        System.out.println("Count of Projects: " + count);

        // Max Budget
        double maxBudget = projects.stream()
                                   .mapToDouble(Project::getBudget)
                                   .max()
                                   .orElse(0.0);
        System.out.println("Max Budget: " + maxBudget);

        // Min Budget
        double minBudget = projects.stream()
                                   .mapToDouble(Project::getBudget)
                                   .min()
                                   .orElse(0.0);
        System.out.println("Min Budget: " + minBudget);

        // Sum Budget
        double totalBudget = projects.stream()
                                     .mapToDouble(Project::getBudget)
                                     .sum();
        System.out.println("Total Budget: " + totalBudget);

        // Average Budget
        double averageBudget = projects.stream()
                                       .mapToDouble(Project::getBudget)
                                       .average()
                                       .orElse(0.0);
        System.out.println("Average Budget: " + averageBudget);
    }
}